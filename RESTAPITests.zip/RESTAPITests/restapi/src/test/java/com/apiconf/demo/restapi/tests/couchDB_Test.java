package com.apiconf.demo.restapi.tests;

import org.junit.Test;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
//import static com.jayway.restassured.*;



public class couchDB_Test {

	
	@Test
	public void postExample()
	{
		
		String myJson = "{\"name\":\"Amit Simu\"}";
		
		RestAssured.baseURI = "http://127.0.0.1:5984/restassured";
		
		Response r = RestAssured.given()
				.contentType("application/json").body("{\"name\":\"Amit Simu\"}").
				when().post("");
		String body = r.getBody().asString();
				System.out.println(body);
		
				
	}
}
