package com.apiconf.demo.restapi.tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.json.JSONArray;
import org.json.JSONException;

import com.jayway.restassured.response.Response;
import static com.jayway.restassured.RestAssured.get;


public class RestApiGETURLTests {

	
	
	@Test
	public void getRequestFindCapital() throws JSONException
	{
		
		Response resp = get("http://restcountries.eu/rest/v1/name/norway");
		
		JSONArray jsonResponse = new JSONArray(resp.asString());
		
		String capital = jsonResponse.getJSONObject(0).getString("capital");
		
		Assert.assertEquals(capital, "Oslo");
	}
	
}
